﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hexaware_project_6._0.Migrations
{
    public partial class innt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
