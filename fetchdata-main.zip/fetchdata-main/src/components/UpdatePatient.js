import { useEffect, useState } from "react"
import {  useNavigate } from "react-router";
 
 
export default function UpdatePatient(){
    // const [gender,setgender] = useState();
    const [id,setid]=useState();
    const[jsonData,setJsonData]=useState({});
    const [firstname, setfirstname] = useState("");
    const [mobile, setmobile] = useState("");
    const [email, setemail] = useState("");
    const [dob, setdob] = useState("");
    const [date, setdate] = useState("");
    const navigate=useNavigate();
 
    useEffect(() => {
        const fetchData = async () => {
            const params = new URLSearchParams(window.location.search).get('data');
            const parsedData = JSON.parse(params);
            setJsonData(parsedData);
            setid(parsedData.id);
            setfirstname(parsedData.firstname);
            setmobile(parsedData.mobile);
            setemail(parsedData.email);
            setdob(parsedData.dob);
            setdate(parsedData.date);
        };
    
        fetchData();
    }, []);
    

    function handleBackClick() {
        navigate('/patient');
      }
 
      function deletePatient(id) {
        try {
          fetch(`https://localhost:7273/api/Patient/Delete/${id}`, {
            method: 'DELETE'
          }).then((result) => {
            result.json().then((resp) => {
              console.warn(resp);
            })
           navigate('/patient')
          })
    
        }
        catch (error) {
          console.log(error);
        }
    
      }
    function Update() {
        try {
          console.log({firstname, dob,mobile,date, email})
          let item = {id, firstname,dob,  mobile,date, email }
          fetch(`https://localhost:7273/api/Patient/UpdatePatient/${jsonData.id}?Firstname=${firstname}&dob =${dob}&mobile=${mobile}&date=${date}&email=${email}`, {
            method: 'PUT',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
          })
            .then((result) => {
    
              navigate('/patient')
            })
           
        }
        catch (error) {
          console.log(error);
        }
       
      
      }
 
    return(
        <>
 
        <center>
        <i class="fa fa-chevron-circle-left" aria-hidden="true" onClick={handleBackClick} style ={{top:"5.7vw", position:"absolute",left:"0.5vw", fontSize:"20px",color:"grey"}}></i>
        <h1 >You're Viewing the patient <b>{jsonData.firstname} </b>details.</h1> <br/>
       
        <form >
        <input type="text" value={firstname} placeholder="firstname" onChange={(e) => setfirstname(e.target.value)}></input><br /><br />
        <input type="hidden" value={dob} placeholder="dob" onChange={(e) => setdob(e.target.value)}></input>
         
         <input type="text" value={mobile} placeholder="mobile" onChange={(e) => setmobile(e.target.value)}></input><br /><br />
         <input type="text" value={date} placeholder="date" onChange={(e) => setdate(e.target.value)}></input><br /><br />
       
         <input type="text" value={email} placeholder="email" onChange={(e) => setemail(e.target.value)}></input><br /><br />
       
        </form>
        <button className="btn btn-danger mr-2" onClick={() => deletePatient(id)}>Delete</button> &nbsp; &nbsp;&nbsp;
        <button className="btn btn-warning mr-2" onClick={() => Update(jsonData.id)}>Update</button> &nbsp; &nbsp;&nbsp;
 
        </center>
       
 
        </>
    )
}