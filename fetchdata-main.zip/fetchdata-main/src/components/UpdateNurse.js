
import { useEffect, useState } from "react"
import { useNavigate } from "react-router";
import{toast,ToastContainer} from 'react-toastify';
 
 
export default function UpdateNurse(){
    
   
    const [id,setid]=useState();
    const[jsonData,setJsonData]=useState({});
    
  const [name, setname] = useState("");
  const [mobile, setmobile] = useState("");
  const [email, setemail] = useState("");
   const [patientId, setpatientId] = useState("");
    const [deviceId, setdeviceId] = useState("");
   const [result, setresult] = useState("");
   const[status,setStatus] = useState("");
    const navigate=useNavigate();
 
    useEffect(() => {
        const fetchData = async () => {
            const params = new URLSearchParams(window.location.search).get('data1');
            const parsedData = JSON.parse(params);
            setJsonData(parsedData);
            setid(parsedData.id);
            setname(parsedData.name);
            setmobile(parsedData.mobile);
            setemail(parsedData.email);
            setpatientId(parsedData.patientId);
            setdeviceId(parsedData.deviceId);
            setresult(parsedData.result);
            setStatus(parsedData.status);

            
        };
    
        fetchData();
    }, []);
    

    function handleBackClick() {
        navigate('/nurse');
      }
      function deleteNurse(id) {
        try {
          fetch(`https://localhost:7273/api/Nurse/Delete/${id}`, {
            method: 'DELETE'
          }).then((result) => {
            console.log(result);
            result.json().then((resp) => {
              console.warn(resp);
            })
          navigate('/nurse');
          toast.success("Deleted Sucessfully");
          })
        
        }
        catch (error) {
          console.log(error);
          toast.error("Error in Deleting Nurse Details")
        }
      }

      function Update() {
        try {
          console.warn(name, mobile, email,status);
          let item = { name, mobile, email, status}
       
          fetch(`https://localhost:7273/api/Nurse/UpdateNurse/${jsonData.id}?name=${name}&mobile=${mobile}&patientId=${patientId}&deviceId=${deviceId}&email=${email}&result=${result}&status=${status}`, {
            method: 'PUT',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
          })
            .then((result) => {
         navigate('/nurse');
         toast.success("Updated Sucessfully");
             
            })
           
        }
        catch (error) {
          console.log(error);
          toast.error("Error in updating nurse");
        }
        
      }
      const renderStatusDropdown = () => {
        return (
          <select value={status} onChange={(e) => setStatus(e.target.value)} style={{width:"16vw", height:"5vh"}}>
            <option value="Assigned">Assigned</option>
            <option value="Free">Free</option>
          </select>
        );
      }
      const renderResultDropdown = () => {
        return (
          <select value={result} onChange={(e) => setresult(e.target.value)} style={{width:"16vw", height:"5vh"}}>
             <option value="">Select Result</option>
            <option value="Positive">Positive</option>
            <option value="Negative">Negative</option>
            <option value="Yet To Declare">Yet To Declare</option>
          </select>
        );
      }
 
    return(
        <>
 <ToastContainer/>
        <center>
        <i class="fa fa-chevron-circle-left" aria-hidden="true" onClick={handleBackClick} style ={{top:"5.7vw", position:"absolute",left:"0.5vw", fontSize:"20px",color:"grey"}}></i>
        <h1 >You're Viewing the Nurse <b>{jsonData.name} </b>details.</h1> <br/>
       
        <form >
        <input type="text" value={name} placeholder="name" onChange={(e) => setname(e.target.value)}></input><br /><br />
          <input type="number" value={mobile} placeholder="mobile" onChange={(e) => setmobile(e.target.value)}></input><br /><br />
          <input type="number" value={patientId} placeholder="patientId" onChange={(e) => setpatientId(e.target.value)}></input><br /><br />
          <input type="number" value={deviceId} placeholder="deviceId" onChange={(e) => setdeviceId(e.target.value)}></input><br /><br />
          <input type="text" value={email} placeholder="email" onChange={(e) => setemail(e.target.value)}></input><br /><br />
          {renderResultDropdown()}
          <br></br><br></br>
            {renderStatusDropdown()}
            <br></br>
        </form>
        <br></br>
        <button className="btn btn-danger mr-2" onClick={() => deleteNurse(id)}>Delete</button> &nbsp; &nbsp;&nbsp;
        <button className="btn btn-warning mr-2" onClick={() => Update(jsonData.id)}>Update</button> &nbsp; &nbsp;&nbsp;
 
        </center>
       
 
        </>
    )
}