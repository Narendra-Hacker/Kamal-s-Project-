
import { useEffect, useState } from "react"
import { useNavigate } from "react-router";
import{toast,ToastContainer} from 'react-toastify';
 
 
export default function UpdateDevice(){
    
   
    const [id,setid]=useState();
    const[jsonData,setJsonData]=useState({});
    
    const [name, setname] = useState("");
    const [patients, setPatients] = useState([]);
    const[patientEmail,setpatientEmail] = useState("");
    const [patientinfo, setpatientinfo] = useState("");
    const[status,setStatus] = useState("");
    const navigate=useNavigate();
 
    useEffect(() => {
        const fetchData = async () => {
            const params = new URLSearchParams(window.location.search).get('data2');
            const parsedData = JSON.parse(params);
            setJsonData(parsedData);
            setid(parsedData.id);
            setname(parsedData.name);
            setpatientEmail(parsedData.patientEmail);
            setpatientinfo(parsedData.patientinfo);
            setStatus(parsedData.status);

            
        };
    
        fetchData();
        fetchPatients();
    }, []);

    const getToken =()=> localStorage.getItem('par') || localStorage.getItem('Token');
    console.log(getToken);
    function fetchPatients() {
        try {
          var token = getToken();
          fetch('https://localhost:7273/api/Patient/GetPatient',{
            headers:{
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            }
          })
            .then((response) => response.json())
            .then((data) => {
              setPatients(data);
              console.log(data);
            })
            .catch((error) => {
              console.log(error);
            });
        }
        catch (error) {
          console.log(error);
        }
      }

    function handleBackClick() {
        navigate('/device');
      }
      function deleteDevice(id) {
        try {
          fetch(`https://localhost:7273/api/Device/Delete/${id}`, {
            method: 'DELETE'
          }).then((result) => {
            result.json().then((resp) => {
              console.warn(resp);
            })
            toast.success("Record Deleted Sucessfully");
            navigate('/device');
          })
        
        }
        catch (error) {
          console.log(error);
          toast.error("Error in deleting Records");
        }
      }
    
     
      function Update() {
        try {
          console.warn(name,patientEmail,  patientinfo,status);
          let item = { name, patientEmail, patientinfo, status}
          fetch(`https://localhost:7273/api/Device/UpdateDevice/${id}?name=${name}&patientEmail=${patientEmail}&result=${patientinfo}&status=${status}`, {
            method: 'PUT',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
          })
            .then((result) => {
          toast.success("Device Updated Sucessfully");
          navigate('/device')
           console.log(result);
            })
           
        }
        catch (error) {
          console.log(error);
          toast.error("Error in Updating Device");
    
        }
       
      }
      const renderStatusDropdown = () => {
        return (
          <select value={status} onChange={(e) => setStatus(e.target.value)} style={{width:"16vw", height:"5vh"}}>
             <option value="">Select status</option>
            <option value="Assigned">Assigned</option>
            <option value="Free">Free</option>
          </select>
        );
      }
      const renderResultDropdown = () => {
        return (
          <select value={patientinfo} onChange={(e) => setpatientinfo(e.target.value)} style={{width:"16vw", height:"5vh"}}>
            <option value="">Select Patient Info</option>
            <option value="Positive">Positive</option>
            <option value="Negative">Negative</option>
            <option value="Yet To Declare">Yet To Declare</option>
          </select>
        );
      }
    
      const renderPatientDropdown = () => {
        return (
          <select value={patientEmail} onChange={(e) => setpatientEmail(e.target.value)} style={{width:"16vw",height:"5vh"}}>
            <option value="">Select Patient</option>
            {patients.map((patient) => (
              <option key={patient.email} value={patient.email}>{patient.email}</option>
            ))}
          </select>
        );
      }
    
    return(
        <>
 <ToastContainer/>
        <center>
        <i class="fa fa-chevron-circle-left" aria-hidden="true" onClick={handleBackClick} style ={{top:"5.7vw", position:"absolute",left:"0.5vw", fontSize:"20px",color:"grey"}}></i>
        <h1 >You're Viewing the Device<b>{jsonData.name} </b>details.</h1> <br/>
       
        <form >
        <input type="text" value={name} placeholder="name" onChange={(e) => setname(e.target.value)} /> <br /><br />
          {renderPatientDropdown()}
          <br></br><br></br>
          {/* <input type="text" value={patientEmail} placeholder="patientEmail" onChange={(e) => setpatientEmail(e.target.value)}></input><br /><br /> */}
          {renderResultDropdown()}
          <br></br><br></br>
          {/* <input type="text" value={status} placeholder="Status" onChange={(e) => setStatus(e.target.value)}></input><br></br><br></br> */}
          {renderStatusDropdown()}
        </form>
        <br></br>
        <button className="btn btn-danger mr-2" onClick={() => deleteDevice(id)}>Delete</button> &nbsp; &nbsp;&nbsp;
        <button className="btn btn-warning mr-2" onClick={() => Update(jsonData.id)}>Update</button> &nbsp; &nbsp;&nbsp;
 
        </center>
       
 
        </>
    )
}