import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import AddPatientDetails from './components/AddPatientDetails';
import Device from './components/Device';
import Patient from './components/Patient';
import Nurse from './components/Nurse';
import AddDeviceDetails from './components/AddDeviceDetails';
import AddNurseDetail from './components/AddNurseDetail';
import MainHeader from './MainHeader'
import HomePage from './HomePage';
import Error from './Error';
import SignupForm from './components/SignupForm';
import Login from './components/Login';
import UserDevice from './components/UserDevice';
import UserPatient from './components/UserPatient';
import UpdatePatient from './components/UpdatePatient';

import UserNurse from './components/UserNurse';
import { ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AuthWrapper from './AuthWrapper';
import NurseDetail from './components/NurseDetails';
import UserPatients from './components/NurseAssignedPatientDetails';
import NurseDevice from './components/NurseAssignedDevice';
import UpdateNurse from './components/UpdateNurse';
import UpdateDevice from './components/UpdateDevice';





function App(props) {
    const role = localStorage.getItem("role") || localStorage.getItem("role1");
   
   
   
   
   
    return <BrowserRouter>
    <ToastContainer/>
        <Routes>
            <Route index element={<SignupForm />} />
            <Route path='/login' element={<Login />} />
               
                <Route path='/' element={<AuthWrapper><MainHeader/></AuthWrapper>}>
                <Route path='/home' element={<HomePage />} />
              
                <Route path='/patient' element={role=== "Admin" ?<Patient /> :<Error/>} />
                <Route path='/nurse' element={role=== "Admin" ? <Nurse />:<Error/>} />
                <Route path='/device' element={role=== "Admin"?<Device />:<Error/>} />
                <Route path='/addpatient' element={role=== "Admin"?<AddPatientDetails />:<Error/>} />
                <Route path='/addnurse' element={role=== "Admin"?<AddNurseDetail />:<Error/>} />
                <Route path='/adddevice' element={role=== "Admin"?<AddDeviceDetails />:<Error/>} />
                <Route path='/UserDevice' element={role=== "Patient"?<UserDevice />:<Error/>} />
                <Route path='/userPatient' element={role=== "Patient"?<UserPatient />:<Error/>} />
                <Route path='/UserNurse' element={role=== "Patient"?<UserNurse />:<Error/>} />
                <Route path='/nurseDetail' element={role=== "Nurse"? <NurseDetail/>:<Error/>}/>
                <Route path='/nurseAssignedPatientDetail' element={role=== "Nurse"?<UserPatients/>:<Error/>}/>
                <Route path ='/nurseAssignedDevice' element={role=== "Nurse"? <NurseDevice/>:<Error/>}/>
                <Route path='/update' element={role=== "Patient" || role=== "Admin" ?<UpdatePatient/>:<Error/>}/>
                <Route path='/updateNurse' element={role=== "Nurse" || role=== "Admin" ? <UpdateNurse/>:<Error/>}/>
                <Route path='/updateDevice' element={role=== "Admin"?<UpdateDevice/>:<Error/>}/>
               
 
            </Route>
          

            <Route path='*' element={<Error />} />
        </Routes>

    </BrowserRouter>

}

export default App;
